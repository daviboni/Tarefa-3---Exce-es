import java.util.Scanner;

public class TarefaArray {
	public static void main(String[] args) {
		Scanner leitor = new Scanner(System.in);
		int [] number = new int[300];
		
		int i =0;
		
		for (i =0; i<300; i++)
		{
			number[i] = 45;
		}
		
		for (i =0; i<300; i++)
		{
			System.out.println("Resultado: " + number[i] + " ");
			System.out.print("Resultado: " + number[i] + " ");
			System.out.printf("Resultado: " + number[i] + " ");
			
		}
		
	}

}
