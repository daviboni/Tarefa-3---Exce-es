import java.util.Scanner;

public class TrabalhandoExJava2 
{
	public static void main(String[] args)
	{
		Scanner leitor = new Scanner(System.in);
		TrabalhoJavaEx av = new TrabalhoJavaEx();
		av.exNome();
		av.mediaIMC();
		
		
		
	}

}
